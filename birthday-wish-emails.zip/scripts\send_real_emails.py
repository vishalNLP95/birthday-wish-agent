import sys
import os
import time
sys.path.insert(0, r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails')
from src import azure_openai, emailer
from pathlib import Path

recipients = [
    'archana_kamath@infosys.com',
    'moses_ferdinand@infosys.com',
    'vishal.c@infosys.com',
]

# derive display name from email local part
def name_from_email(email: str) -> str:
    local = email.split('@')[0]
    # replace underscores, dots with space and title-case
    name = local.replace('_', ' ').replace('.', ' ').title()
    return name

# Prepare assets
project_root = Path(__file__).resolve().parents[1]
svgs = ['balloon.svg', 'cake.svg', 'confetti.svg']

# Variant temperatures for diversity
temperatures = [0.6, 0.7, 0.85]

results = []
for variant_idx in range(3):
    temp = temperatures[variant_idx % len(temperatures)]
    for email in recipients:
        name = name_from_email(email)
        try:
            # generate concise fun fact and age
            fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=None, temperature=temp, max_tokens=120)
        except Exception as e:
            print(f"Generation failed for {email}: {e}")
            results.append((email, False, f"generation error: {e}"))
            continue

        # theme selection
        from src.templates.theme_variants import get_theme, get_header_variant
        import random
        theme = get_theme()
        header_text = get_header_variant()
        svg_name = random.choice(svgs)
        svg_path = project_root / 'src' / 'assets' / svg_name
        inline_svg = None
        try:
            with open(svg_path, 'r', encoding='utf-8') as sf:
                inline_svg = sf.read()
        except Exception:
            inline_svg = None

        html = emailer.render_email_html(name, fun_fact, theme=theme, header_text=header_text, inline_svg=inline_svg, age_text=age_text)
        subject = f"Happy Birthday, {name}! - TEST AI Agent from Vishal"        try:
            emailer.send_email(email, subject, html, dry_run=False)
            print(f"Sent variant {variant_idx+1} to {email}")
            results.append((email, True, None))
        except Exception as e:
            print(f"Failed to send to {email}: {e}")
            results.append((email, False, str(e)))
        # small delay between sends
        time.sleep(1)

# Summary
print('\nSend summary:')
for r in results:
    print(r)
