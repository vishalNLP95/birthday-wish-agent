"""
Azure-compatible OpenAI wrapper using the OpenAI Python SDK.

Loads configuration from environment (optionally a .env file) and exposes a simple
helper generate_birthday_message(name) that returns a short personalized birthday
message with a cheerful trivia or fun fact about the recipient's day/month/year of
birth. The function is intentionally lightweight so it can be used synchronously
in an email pipeline.

This module is written to work with Azure OpenAI deployments via the `openai`
Python package configured for Azure (api_type = "azure").

Environment variables used (see .env.example):
- AZURE_OPENAI_KEY
- AZURE_OPENAI_ENDPOINT (e.g., https://your-resource-name.openai.azure.com/)
- AZURE_OPENAI_DEPLOYMENT_NAME (the deployment/model name)

"""
from __future__ import annotations

import os
import logging
from typing import Optional

from dotenv import load_dotenv

# Use the OpenAI python SDK (>=1.0.0) which supports Azure-style configuration.
from openai import AzureOpenAI

logger = logging.getLogger(__name__)

# Load example.env from the project root if present, otherwise fall back to a default .env
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
example_env = project_root / "example.env"
if example_env.exists():
    load_dotenv(str(example_env))
    logger.info("Loaded environment variables from %s", example_env)
else:
    # Fall back to default behavior (load .env if present)
    load_dotenv()
    logger.info("Loaded environment variables from default .env if present")

AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")

if not AZURE_OPENAI_KEY or not AZURE_OPENAI_ENDPOINT or not AZURE_OPENAI_DEPLOYMENT_NAME:
    logger.warning(
        "One or more Azure OpenAI environment variables are missing. "
        "AZURE_OPENAI_KEY: %s, AZURE_OPENAI_ENDPOINT: %s, AZURE_OPENAI_DEPLOYMENT_NAME: %s",
        bool(AZURE_OPENAI_KEY), bool(AZURE_OPENAI_ENDPOINT), bool(AZURE_OPENAI_DEPLOYMENT_NAME),
    )

# Initialize client for Azure OpenAI. Provide a callable initializer so the client can be
# reinitialized at runtime if example.env is updated after module import.
_client: Optional[AzureOpenAI] = None

def init_client(force_reload: bool = False) -> Optional[OpenAI]:
    """(Re)initialize the OpenAI client from environment variables.

    If force_reload is True, attempts to reload example.env (if present) into the process
    environment so edits to example.env are picked up without restarting Python.
    Returns the OpenAI client or None if configuration is missing.
    """
    global _client, AZURE_OPENAI_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT_NAME
    try:
        if force_reload:
            # reload from example.env if present (override existing vars)
            try:
                load_dotenv(str(example_env), override=True)
                logger.info("Reloaded environment variables from %s", example_env)
            except TypeError:
                # older python-dotenv versions use "override" named differently — fallback to default load
                load_dotenv(str(example_env))
                logger.info("Reloaded environment variables from %s (no-override mode)", example_env)

        # refresh env var captures
        AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY")
        AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
        AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")

        if not AZURE_OPENAI_KEY or not AZURE_OPENAI_ENDPOINT:
            logger.warning("Azure OpenAI key/endpoint still not set after reload. Skipping client init.")
            _client = None
            return None

        # Initialize AzureOpenAI client directly using the Azure-specific constructor
        AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", AZURE_OPENAI_API_VERSION)
        _client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_version=AZURE_OPENAI_API_VERSION,
        )
        logger.info("AzureOpenAI client initialized for endpoint %s", AZURE_OPENAI_ENDPOINT)
        return _client
    except Exception as ex:
        logger.exception("Failed to initialize OpenAI client: %s", ex)
        _client = None
        return None

# Try an initial (non-forcing) init; this will succeed if example.env had values at import time
try:
    if AZURE_OPENAI_KEY and AZURE_OPENAI_ENDPOINT:
        _client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_version=AZURE_OPENAI_API_VERSION,
        )
except Exception as ex:
    logger.exception("Failed to initialize AzureOpenAI client at import: %s", ex)
    _client = None


def _ordinal(n: int) -> str:
    """Return ordinal suffix for integer n (1 -> '1st', 2 -> '2nd', etc.)."""
    n = int(n)
    if 10 <= (n % 100) <= 20:
        return f"{n}th"
    if n % 10 == 1:
        return f"{n}st"
    if n % 10 == 2:
        return f"{n}nd"
    if n % 10 == 3:
        return f"{n}rd"
    return f"{n}th"


def _build_prompt(name: str, dob_text: Optional[str] = None, focus: Optional[str] = None, age_text: Optional[str] = None) -> str:
    """Construct a concise prompt that requests a single fun-fact sentence (or two) only.

    The model should output only the fun fact text — no greetings, no wishes, no signature. The fact should be
    positive, non-controversial, and based on the chosen focus when possible (sun_sign, name_initial, date, month, year).
    Keep the response concise (one or two short sentences).
    """
    focus_phrases = {
        "sun_sign": "Relate the fact to a short, positive sun-sign trait if day/month is available.",
        "name_initial": "Optionally use a friendly positive note tied to the recipient's name or initial (positive adjective or alliteration).",
        "date": "Mention a pleasant, widely-known positive event or figure associated with that calendar day.",
        "month": "Offer a cheerful seasonal or cultural note about the birth month (festivals, seasons, or general positive traits).",
        "year": "Mention a short, upbeat milestone or pop-culture highlight from the birth year that is positive and non-controversial.",
    }
    focus_phrase = focus_phrases.get(focus or "month", focus_phrases["month"])

    if dob_text:
        prompt = (
            f"You are a helpful assistant producing exactly one concise, positive fun fact (1-2 short sentences) for use inside a professional birthday email from the Recruitment Team. "
            f"Given recipient {name} and DOB {dob_text}, produce only the fun fact text (no greeting, no wishes, no signature). "
            f"Use the chosen focus: {focus}. {focus_phrase} Keep it non-controversial and suitable for a professional outreach."
        )
    else:
        prompt = (
            f"You are a helpful assistant producing exactly one concise, positive fun fact (1-2 short sentences) for use inside a professional birthday email from the Recruitment Team. "
            f"Given recipient {name}, produce only the fun fact text (no greeting, no wishes, no signature). "
            f"Use the chosen focus: {focus}. {focus_phrase} Keep it non-controversial and suitable for a professional outreach."
        )
    return prompt
    return prompt


def generate_birthday_message(name: str, dob: Optional[object] = None, max_tokens: int = 200, temperature: float = 0.7) -> str:
    """Generate a short personalized birthday message for `name`.

    Parameters:
    - name: recipient's name (string)
    - max_tokens: max tokens for the completion
    - temperature: sampling temperature

    Returns a string with the generated message. Raises RuntimeError if the client is not configured
    or the API call fails.
    """
    global _client, AZURE_OPENAI_DEPLOYMENT_NAME
    # If client is not initialized (for example example.env was updated after import), try to init
    if not _client:
        init_client(force_reload=True)
    if not _client:
        raise RuntimeError("OpenAI client not configured. Set AZURE_OPENAI_KEY and AZURE_OPENAI_ENDPOINT.")

    if not AZURE_OPENAI_DEPLOYMENT_NAME:
        # attempt to refresh env var in case example.env provided it
        AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        if not AZURE_OPENAI_DEPLOYMENT_NAME:
            raise RuntimeError("AZURE_OPENAI_DEPLOYMENT_NAME is not set. Specify the deployment/model name.")

    # prepare dob_text and compute age if dob provided
    dob_text = None
    age_text = None
    if dob is not None:
        # Accept datetime/date or string; convert to readable string and compute age
        try:
            from datetime import date, datetime
            from dateutil import parser as date_parser

            if isinstance(dob, (datetime, date)):
                bdate = dob.date() if isinstance(dob, datetime) else dob
            else:
                # parse flexible date strings
                bdate = date_parser.parse(str(dob)).date()
            dob_text = bdate.isoformat()
            today = date.today()
            years = today.year - bdate.year - ((today.month, today.day) < (bdate.month, bdate.day))
            if years >= 0:
                age_text = _ordinal(years)
        except Exception:
            try:
                dob_text = str(dob)
            except Exception:
                dob_text = None

    # choose a random focus for prompt diversity
    import random
    focuses = ["sun_sign", "name_initial", "date", "month", "year"]
    focus = random.choice(focuses)

    prompt = _build_prompt(name, dob_text=dob_text, focus=focus, age_text=age_text)

    try:
        # Use the chat completions path. Request only the fun fact from the model (no greetings or signature)
        response = _client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT_NAME,
            messages=[
                {"role": "system", "content": "You are a helpful assistant that generates a single concise, non-controversial fun fact for a birthday email. Output only the fact sentence(s), no greetings, no signatures."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )

        # Response shape: response.choices[0].message.content
        if not response or not getattr(response, "choices", None):
            raise RuntimeError("Empty response from OpenAI chat completion")

        # Defensive extraction of text
        choice = response.choices[0]
        message_text = ""
        if hasattr(choice, "message") and choice.message and getattr(choice.message, "content", None):
            message_text = choice.message.content
        elif getattr(choice, "text", None):
            message_text = choice.text
        else:
            # Fallback to string conversion
            message_text = str(choice)

        fun_fact = message_text.strip()
        # return tuple: (fun_fact, age_text) so caller can append age sentence in template
        return fun_fact, age_text
    except Exception as ex:
        logger.exception("OpenAI request failed: %s", ex)
        raise


if __name__ == "__main__":
    # simple local test when run as a script
    logging.basicConfig(level=logging.INFO)
    try:
        # Test with common Indian names, with and without DOB
        test_cases = [
            ("Amit", "1990-08-15"),
            ("Priya", None),
            ("Rahul", "1988-10-05"),
        ]
        for name, dob in test_cases:
            print('\n---\n')
            print(f"Generating message for: {name}, dob={dob}")
            try:
                msg = generate_birthday_message(name, dob=dob)
                print(msg)
            except Exception as e:
                print('Generation failed for', name, ':', e)
    except Exception as e:
        logger.error("Test failed: %s", e)
