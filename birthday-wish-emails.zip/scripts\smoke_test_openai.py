from src import azure_openai
import os

print("AZURE_OPENAI_KEY set:", bool(os.getenv("AZURE_OPENAI_KEY")))
print("AZURE_OPENAI_ENDPOINT set:", bool(os.getenv("AZURE_OPENAI_ENDPOINT")))
print("AZURE_OPENAI_DEPLOYMENT_NAME set:", bool(os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")))

client_present = getattr(azure_openai, "_client", None) is not None
print("Internal OpenAI client initialized:", client_present)

if client_present and os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"):
    try:
        msg = azure_openai.generate_birthday_message("Alex")
        print("\nGenerated message:\n")
        print(msg)
    except Exception as e:
        print("API call failed:", e)
else:
    print("\nSkipping API call due to missing configuration. To run, set AZURE_OPENAI_KEY, AZURE_OPENAI_ENDPOINT, and AZURE_OPENAI_DEPLOYMENT_NAME in your environment or .env file.")
