import sys
import os
import time
sys.path.insert(0, r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails')
from src import azure_openai, emailer
from pathlib import Path

recipient = 'vishal.c@infosys.com'
name = recipient.split('@')[0].replace('_', ' ').replace('.', ' ').title()

project_root = Path(__file__).resolve().parents[1]
svgs = ['balloon.svg', 'cake.svg', 'confetti.svg']

# how many emails to send (choose within 10-15)
count = 12

results = []
for i in range(1, count + 1):
    try:
        # vary temperature slightly for diversity
        import random
        temp = random.choice([0.6, 0.7, 0.8, 0.85])
        fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=None, temperature=temp, max_tokens=120)
    except Exception as e:
        print(f"Generation failed for {recipient}: {e}")
        results.append((i, False, f"generation error: {e}"))
        continue

    # select theme and header
    from src.templates.theme_variants import get_theme, get_header_variant
    theme = get_theme()
    header_text = get_header_variant()

    # pick svg
    import random
    svg_name = random.choice(svgs)
    svg_path = project_root / 'src' / 'assets' / svg_name
    inline_svg = None
    try:
        with open(svg_path, 'r', encoding='utf-8') as sf:
            inline_svg = sf.read()
    except Exception:
        inline_svg = None

    html = emailer.render_email_html(name, fun_fact, theme=theme, header_text=header_text, inline_svg=inline_svg, age_text=age_text)
    subject = f"TEST #{i} - Happy Birthday, {name}! - TEST AI Agent from Vishal"

    try:
        emailer.send_email(recipient, subject, html, dry_run=False)
        print(f"Sent {i}/{count} to {recipient}")
        results.append((i, True, None))
    except Exception as e:
        print(f"Failed to send {i} to {recipient}: {e}")
        results.append((i, False, str(e)))

    time.sleep(1)

print('\nSummary:')
for r in results:
    print(r)
