import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import azure_openai, emailer
from src.templates.theme_variants import get_theme, get_header_variant

recipient = 'vishal.c@infosys.com'
name = recipient.split('@')[0].replace('_', ' ').replace('.', ' ').title()

for i in range(1, 3):
    try:
        fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=None, temperature=0.7, max_tokens=120)
    except Exception as e:
        print('Generation failed:', e)
        continue

    theme = get_theme()
    header_text = get_header_variant(name=name)

    html = emailer.render_email_html(name, fun_fact, theme=theme, header_text=header_text, inline_svg=None, age_text=age_text)
    subject = f"TEST Sample #{i} - Happy Birthday, {name}! - TEST AI Agent from Vishal"

    try:
        emailer.send_email(recipient, subject, html, dry_run=False)
        print(f"Sent sample {i} to {recipient}")
    except Exception as e:
        print(f"Failed to send sample {i}:", e)
    time.sleep(1)
