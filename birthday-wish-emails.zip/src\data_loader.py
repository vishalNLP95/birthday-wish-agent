"""
Data loader for Birthday Wish Emails project.

Provides helpers to load candidate data (name, email, date of birth) from:
- Local Excel files (pandas/openpyxl)
- Google Sheets URLs (gspread + service account json)

The functions normalize columns and return a pandas.DataFrame with at least these columns:
- name: str (may be None)
- email: str (may be None)
- dob: pandas.Timestamp (parsed; NaT for unparsable values)

Example usage:
>>> from src.data_loader import load_candidates
>>> df = load_candidates(r"C:\data\candidates.xlsx")
>>> df = load_candidates("https://docs.google.com/spreadsheets/d/...", credentials_json_path="/path/creds.json")
"""
from __future__ import annotations

import os
import logging
from typing import Optional

import pandas as pd
import gspread

logger = logging.getLogger(__name__)


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Lowercase and strip column names for easier detection."""
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    return df


def _guess_columns(columns: list[str]) -> dict:
    """Return a guess map for name/email/dob column names based on heuristics."""
    name_col = None
    email_col = None
    dob_col = None
    for c in columns:
        if name_col is None and ("name" in c or "candidate" in c or "full" in c):
            name_col = c
        if email_col is None and ("email" in c or "e-mail" in c):
            email_col = c
        if dob_col is None and ("dob" in c or "dateofbirth" in c or "date_of_birth" in c or ("birth" in c and "date" in c) or "birthday" in c):
            dob_col = c
    return {"name": name_col, "email": email_col, "dob": dob_col}


def _ensure_columns(df: pd.DataFrame, name_col: Optional[str], email_col: Optional[str], dob_col: Optional[str]) -> tuple[str, str, str]:
    """Validate or guess column names and return the chosen names (from df columns).

    Raises ValueError if dob column cannot be identified.
    """
    cols = list(df.columns)
    guesses = _guess_columns(cols)

    name_col_final = name_col if name_col in cols else guesses["name"]
    email_col_final = email_col if email_col in cols else guesses["email"]
    dob_col_final = dob_col if dob_col in cols else guesses["dob"]

    if dob_col_final is None:
        raise ValueError(
            f"Could not detect a date-of-birth column. Available columns: {cols}. Provide dob_col explicitly."
        )

    return name_col_final, email_col_final, dob_col_final


def load_from_excel(
    path: str,
    sheet_name: Optional[str] = None,
    name_col: Optional[str] = None,
    email_col: Optional[str] = None,
    dob_col: Optional[str] = None,
) -> pd.DataFrame:
    """Load candidates from a local Excel file into a normalized DataFrame.

    Parameters:
    - path: local path to the Excel file
    - sheet_name: optional sheet name or index for pandas.read_excel
    - name_col/email_col/dob_col: optional explicit column names (case-insensitive)

    Returns DataFrame with columns: name, email, dob (datetime64[ns]).
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Excel file not found: {path}")

    df = pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")
    df = _normalize_columns(df)

    # tolerate user passing original column names in any case
    name_col = name_col.lower() if name_col else None
    email_col = email_col.lower() if email_col else None
    dob_col = dob_col.lower() if dob_col else None

    name_col_final, email_col_final, dob_col_final = _ensure_columns(df, name_col, email_col, dob_col)

    # build result
    result = pd.DataFrame()
    result["name"] = df[name_col_final] if name_col_final in df.columns else None
    result["email"] = df[email_col_final] if (email_col_final and email_col_final in df.columns) else None
    result["dob"] = pd.to_datetime(df[dob_col_final], errors="coerce")

    return result


def _is_gsheet_url(s: str) -> bool:
    if not isinstance(s, str):
        return False
    return "docs.google.com/spreadsheets" in s or s.strip().startswith("https://") and "gid=" in s


def load_from_gsheet(
    sheet_url: str,
    credentials_json_path: Optional[str] = None,
    sheet_name: Optional[str] = None,
    name_col: Optional[str] = None,
    email_col: Optional[str] = None,
    dob_col: Optional[str] = None,
) -> pd.DataFrame:
    """Load candidates from a Google Sheets URL using a service account JSON.

    Parameters:
    - sheet_url: full Google Sheets URL or spreadsheet ID
    - credentials_json_path: path to service account json. If omitted the env var GOOGLE_CREDENTIALS_JSON_PATH is used.
    - sheet_name: optional worksheet name

    Returns DataFrame with columns: name, email, dob (datetime64[ns]).

    Notes:
    - Requires gspread and a Google service account with Sheets API access.
    """
    creds = credentials_json_path or os.getenv("GOOGLE_CREDENTIALS_JSON_PATH")
    if creds is None:
        raise ValueError("Google credentials JSON path not provided and GOOGLE_CREDENTIALS_JSON_PATH is not set.")
    if not os.path.exists(creds):
        raise FileNotFoundError(f"Google credentials file not found: {creds}")

    sa = gspread.service_account(filename=creds)

    # open by URL or key
    try:
        if "docs.google.com" in sheet_url:
            sh = sa.open_by_url(sheet_url)
        else:
            sh = sa.open_by_key(sheet_url)
    except Exception as ex:
        logger.exception("Failed to open Google Sheet: %s", ex)
        raise

    ws = sh.worksheet(sheet_name) if sheet_name else sh.sheet1

    rows = ws.get_all_values()
    if not rows or len(rows) < 1:
        return pd.DataFrame(columns=["name", "email", "dob"])  # empty

    header = [str(h).strip() for h in rows[0]]
    data_rows = rows[1:]
    df = pd.DataFrame(data_rows, columns=header)

    df = _normalize_columns(df)

    # tolerate user passing original column names in any case
    name_col = name_col.lower() if name_col else None
    email_col = email_col.lower() if email_col else None
    dob_col = dob_col.lower() if dob_col else None

    name_col_final, email_col_final, dob_col_final = _ensure_columns(df, name_col, email_col, dob_col)

    result = pd.DataFrame()
    result["name"] = df[name_col_final] if name_col_final in df.columns else None
    result["email"] = df[email_col_final] if (email_col_final and email_col_final in df.columns) else None
    result["dob"] = pd.to_datetime(df[dob_col_final], errors="coerce")

    return result


def load_candidates(
    source: str,
    *,
    sheet_name: Optional[str] = None,
    credentials_json_path: Optional[str] = None,
    name_col: Optional[str] = None,
    email_col: Optional[str] = None,
    dob_col: Optional[str] = None,
) -> pd.DataFrame:
    """Unified loader that detects source type and returns normalized DataFrame.

    - If source is a path to an existing local file, loads Excel.
    - If source looks like a Google Sheets URL or ID, loads via gspread.

    The returned DataFrame always has columns: name, email, dob
    """
    # prefer local file if exists
    if os.path.exists(source):
        return load_from_excel(source, sheet_name=sheet_name, name_col=name_col, email_col=email_col, dob_col=dob_col)

    # otherwise assume gsheet url or id
    if _is_gsheet_url(source) or (not os.path.exists(source) and "docs.google.com" in source) or len(source) == 44:
        return load_from_gsheet(source, credentials_json_path=credentials_json_path, sheet_name=sheet_name, name_col=name_col, email_col=email_col, dob_col=dob_col)

    raise ValueError(f"Source not found or not recognized as Excel file or Google Sheet URL: {source}")
