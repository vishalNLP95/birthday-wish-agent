import sys
import os
sys.path.insert(0, r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails')
from src import azure_openai

cases = [
    ("Saanvi", "1995-03-28"),
    ("Vikram", "1985-12-11"),
    ("Neha", "1992-06-07"),
]

for name, dob in cases:
    print('\n---')
    print(f'Generating for {name}, dob={dob}')
    try:
        fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=dob)
        preview = f"Dear {name},\n\n" + fun_fact + "\n\n"
        if age_text:
            preview += f"Wishing you on your {age_text} birthday.\n"
        print(preview)
    except Exception as e:
        print('Generation failed for', name, ':', e)
