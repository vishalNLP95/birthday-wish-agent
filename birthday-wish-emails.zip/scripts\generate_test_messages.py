import sys
import os
sys.path.insert(0, r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails')
from src import azure_openai
import logging
import traceback

logging.basicConfig(level=logging.INFO)
print('example.env exists:', os.path.exists(os.path.join(r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails','example.env')))
print('AZURE_OPENAI_KEY set:', bool(os.getenv('AZURE_OPENAI_KEY')))
print('AZURE_OPENAI_ENDPOINT set:', bool(os.getenv('AZURE_OPENAI_ENDPOINT')))
print('AZURE_OPENAI_DEPLOYMENT_NAME set:', bool(os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')))
print('Internal client present:', getattr(azure_openai, '_client', None) is not None)

cases = [
    ("Amit", "1990-08-15"),
    ("Priya", None),
    ("Rahul", "1988-10-05"),
]

for name, dob in cases:
    print('\n---')
    print(f'Generating for {name}, dob={dob}')
    try:
        fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=dob)
        # compose preview text similar to final email body (header/template handled elsewhere)
        preview = ''
        preview += f"Dear {name},\n\n"
        preview += fun_fact + "\n\n"
        if age_text:
            preview += f"Wishing you on your {age_text} birthday.\n"
        print(preview)
    except Exception:
        traceback.print_exc()
        print('Generation failed for', name)
