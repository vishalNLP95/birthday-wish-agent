"""
Email utilities: render Jinja2 templates and send emails via SMTP.

Functions:
- render_email_html(name, message): returns HTML string rendered from templates/birthday_email.html
- send_email(to_email, subject, html_body, dry_run=True): sends email via SMTP using env vars or prints when dry_run

Environment variables (example.env):
- SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM_NAME, SMTP_FROM_EMAIL
"""
from __future__ import annotations

import os
import logging
from typing import Optional
from dotenv import load_dotenv
from jinja2 import Environment, FileSystemLoader, select_autoescape
from email.message import EmailMessage
from email.utils import formataddr
import smtplib

logger = logging.getLogger(__name__)

# Load example.env if present
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
example_env = project_root / "example.env"
if example_env.exists():
    load_dotenv(str(example_env))
else:
    load_dotenv()

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
SMTP_FROM_NAME = os.getenv("SMTP_FROM_NAME", "Recruiter")
SMTP_FROM_EMAIL = os.getenv("SMTP_FROM_EMAIL")

# Jinja2 environment
_templates_dir = project_root / "src" / "templates"
_jinja_env = Environment(
    loader=FileSystemLoader(str(_templates_dir)),
    autoescape=select_autoescape(["html", "xml"]),
)


def render_email_html(name: str, fun_fact: str, theme: Optional[dict] = None, header_text: Optional[str] = None, inline_svg: Optional[str] = None, age_text: Optional[str] = None) -> str:
    """Render the birthday email HTML using the company-branded table template.

    This function loads src/templates/infosys_birthday_template.html and substitutes
    placeholders. It also sanitizes the fun_fact to avoid duplicated "Did you know?" prefixes.
    """
    # safe defaults
    if theme is None:
        from src.templates.theme_variants import get_theme
        theme = get_theme()

    # Template values
    hero_text = theme.get("header_emoji_text", "Happy Birthday, {name}!").format(name=name)
    footer_text = theme.get("footer_text", "Best wishes")

    # Header body text (longer paragraph below hero)
    if header_text is None:
        from src.templates.theme_variants import get_header_variant
        header_text = get_header_variant(name=name)

    # Sanitize header_text: remove leading salutations like "Dear {name},", "Hi {name},", etc.
    import re
    hdr = (header_text or "").strip()
    # ensure it's a string with the name already formatted (get_header_variant returns formatted)
    # pattern to remove common salutations that include the recipient's name
    pattern = r'^\s*(?:Dear|Hi|Hey|Hola|Hello)\s+' + re.escape(name) + r"[\s,!.:-]*"
    hdr = re.sub(pattern, '', hdr, flags=re.I)
    # also remove a leading standalone name e.g., "Vishal," if present
    pattern2 = r'^\s*' + re.escape(name) + r"[\s,!.:-]*"
    hdr = re.sub(pattern2, '', hdr, flags=re.I)
    header_text_clean = hdr.lstrip()
    # Capitalize the first character of the restored header line to ensure it starts with a capital
    header_text_clean = header_text_clean.strip()
    if header_text_clean:
        header_text_clean = header_text_clean[0].upper() + header_text_clean[1:]

    # Build a standardized greeting line (replace previous 'Hi {name},')
    greeting = f"Dear {name},"

    # Sanitize fun_fact: remove any leading "Did you know?" that may have been included
    ff = (fun_fact or "").strip()
    if ff.lower().startswith("did you know?"):
        # remove the prefix and any following punctuation/space
        ff = ff[len("did you know?"):].lstrip(" :.-–—")
    # Ensure no surrounding whitespace
    ff = ff.strip()

    # Build age block if provided
    age_block = ""
    if age_text:
        age_block = f"<p style=\"margin:12px 0 0 0;padding:0;font-weight:600;text-align:center;\">Wishing you on your {age_text} birthday.</p>"

    # logo URL (placeholder random company asset)
    # Using a placeholder image (Acme Corporation) — replace with any company logo URL as needed.
    logo_url = os.getenv("TEMPLATE_LOGO_URL", "https://placehold.co/210x60?text=Acme+Corp")
    company_name = os.getenv("TEMPLATE_COMPANY_NAME", "Acme Corporation")

    # Load template file
    template_path = _templates_dir / "infosys_birthday_template.html"
    try:
        tpl = template_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.exception("Failed to read template %s: %s", template_path, e)
        # Fallback: simple inline fallback template
        tpl = (
            "<html><body><h1 style='background:#007CC3;color:#fff;padding:12px;'>%s</h1>"
            "<p>%s</p><p>💡Did you know? %s</p><p>%s</p></body></html>"
        )
        return tpl % (hero_text, header_text_clean, ff, footer_text)

    html = tpl.format(
        logo_url=logo_url,
        hero_text=hero_text,
        name=name,
        greeting=greeting,
        header_text=header_text_clean,
        fun_fact=ff,
        age_text=age_text or "",
        footer_text=footer_text,
        age_block=age_block,
    )
    return html


def send_email(
    to_email: str,
    subject: str,
    html_body: str,
    dry_run: bool = True,
    from_name: Optional[str] = None,
    from_email: Optional[str] = None,
    save_to: Optional[str] = None,
) -> bool:
    """Send an email via SMTP. If dry_run is True, writes the rendered HTML to data/output_emails and prints summary safely in UTF-8.

    Returns True on success (or dry-run), raises on error when sending.
    """
    from_name = from_name or SMTP_FROM_NAME
    from_email = from_email or SMTP_FROM_EMAIL

    # ensure output directory exists when saving
    output_dir = Path(project_root / "data" / "output_emails")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save HTML file for record/preview
    safe_name = to_email or "unknown"
    filename = f"{safe_name}.html"
    path = output_dir / filename
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(html_body)
    except Exception as e:
        logger.exception("Failed to write preview HTML to %s: %s", path, e)

    if dry_run or not SMTP_HOST or not SMTP_USER or not SMTP_PASSWORD or not from_email:
        # Print a dry-run summary using UTF-8-safe write
        logger.info("Dry-run email to %s: subject=%s (preview saved to %s)", to_email, subject, path)
        try:
            import sys
            output = (
                "---\nDry-run email\nTo: " + str(to_email) + "\n"
                + "From: " + formataddr((from_name, from_email or "(not set)")) + "\n"
                + "Subject: " + subject + "\nHTML body:\n" + html_body
            )
            # write bytes to stdout.buffer when available to avoid encoding errors
            if hasattr(sys.stdout, "buffer"):
                sys.stdout.buffer.write(output.encode("utf-8", errors="replace"))
                sys.stdout.buffer.write(b"\n")
            else:
                print(output)
        except Exception:
            print("Could not print preview to console; preview saved to", path)
        return True

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = formataddr((from_name, from_email))
    msg["To"] = to_email
    # set a plain-text alternative
    plain_text = _html_to_text(html_body)
    msg.set_content(plain_text)
    msg.add_alternative(html_body, subtype="html")

    # Send via SMTP with TLS
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.login(SMTP_USER, SMTP_PASSWORD)
        smtp.send_message(msg)

    logger.info("Sent email to %s via %s", to_email, SMTP_HOST)
    return True


def _html_to_text(html: str) -> str:
    # Very small fallback: strip tags naively. For production, use html2text or similar.
    import re

    text = re.sub(r"<br\s*/?>", "\n", html)
    text = re.sub(r"<[^>]+>", "", text)
    return text.strip()
