"""
Demo pipeline: generate birthday messages for a small sample of candidates, render template, and optionally send via SMTP.

Usage:
    python scripts\run_pipeline.py [--send]

By default runs in dry-run mode and prints the generated messages. Use --send to attempt actual SMTP sends (requires SMTP_* env vars configured in example.env).
"""
import sys
import os
import argparse
sys.path.insert(0, r'C:\Users\Asus\Desktop\AI Agents\Birthday Wish Emails')

from src import data_loader
from src import azure_openai
from src import emailer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--send", action="store_true", help="Actually send emails via SMTP (requires SMTP config)")
    args = parser.parse_args()

    # small sample candidates (name, email, dob)
    candidates = [
        {"name": "Saanvi", "email": "saanvi@example.com", "dob": "1995-03-28"},
        {"name": "Vikram", "email": "vikram@example.com", "dob": "1985-12-11"},
        {"name": "Neha", "email": "neha@example.com", "dob": "1992-06-07"},
    ]

    for c in candidates:
        name = c["name"]
        email = c.get("email")
        dob = c.get("dob")
        print("\n---\n")
        print(f"Generating message for {name} (dob={dob})")
        try:
            fun_fact, age_text = azure_openai.generate_birthday_message(name, dob=dob)
        except Exception as e:
            print("Failed to generate message for", name, ":", e)
            continue

        # Choose a theme and asset to make each message visually unique
        from src.templates.theme_variants import get_theme, get_header_variant
        import random
        svgs = ["balloon.svg", "cake.svg", "confetti.svg"]
        theme = get_theme()
        header_text = get_header_variant()
        svg_name = random.choice(svgs)
        from pathlib import Path
        project_root = Path(__file__).resolve().parents[1]
        svg_path = project_root / "src" / "assets" / svg_name
        inline_svg = None
        try:
            with open(svg_path, "r", encoding="utf-8") as sf:
                inline_svg = sf.read()
        except Exception:
            inline_svg = None

        # emailer.render_email_html now expects fun_fact and theme dict
        html = emailer.render_email_html(name, fun_fact=fun_fact, theme=theme, header_text=header_text, inline_svg=inline_svg, age_text=age_text)
        subject = f"Happy Birthday, {name}! - TEST AI Agent from Vishal"

        # dry-run unless --send provided
        try:
            emailer.send_email(email, subject, html, dry_run=not args.send)
        except Exception as e:
            print("Failed to send email to", email, ":", e)


if __name__ == "__main__":
    main()
