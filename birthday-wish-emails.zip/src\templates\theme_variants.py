"""
Theme variants for birthday emails — simplified to only header_emoji_text and footer_text
as requested: fixed brand colors are applied in the HTML template. Provides 15
consistent theme entries (matching the 15 header variants) and helpers to pick one.
"""
from typing import Dict, Optional
import random

THEMES = [
    {
        "theme_name": "Confetti Celebration",
        "header_emoji_text": "🎉 Happy Birthday, {name}! 🎊",
        "footer_text": "With confetti and cheer — Team 🎊",
    },
    {
        "theme_name": "Golden Cake",
        "header_emoji_text": "🎂 It's Your Day, {name}! ✨",
        "footer_text": "Wishing you golden moments ahead 🎂",
    },
    {
        "theme_name": "Balloon Pop",
        "header_emoji_text": "🎈 Happy Birthday, {name}! 🥳",
        "footer_text": "Floating good wishes your way 🎈",
    },
    {
        "theme_name": "Starry Night",
        "header_emoji_text": "⭐ Happy Birthday, {name}! 🌙",
        "footer_text": "Wishing you a star-studded year ⭐",
    },
    {
        "theme_name": "Tropical Fiesta",
        "header_emoji_text": "🌴 ¡Feliz Cumpleaños, {name}! 🍹",
        "footer_text": "Stay cool, stay celebrated 🌴",
    },
    {
        "theme_name": "Rainbow Burst",
        "header_emoji_text": "🌈 Happy Birthday, {name}! 🎆",
        "footer_text": "Here's to color and joy all year 🌈",
    },
    {
        "theme_name": "Minimalist Elegant",
        "header_emoji_text": "Happy Birthday, {name} 🥂",
        "footer_text": "With warm regards — The Team",
    },
    {
        "theme_name": "Floral Bloom",
        "header_emoji_text": "🌸 Blooming Wishes, {name}! 🌺",
        "footer_text": "May your year bloom beautifully 🌸",
    },
    {
        "theme_name": "Cosmic Sparkle",
        "header_emoji_text": "✨ Happy Birthday, {name}! 🚀",
        "footer_text": "Reaching for the stars with you ✨",
    },
    {
        "theme_name": "Party Popper Classic",
        "header_emoji_text": "🎉 Happy Birthday, {name}! 🎁",
        "footer_text": "Pop, cheer, celebrate! 🎉",
    },
    {
        "theme_name": "Sunset Glow",
        "header_emoji_text": "🌅 Happy Birthday, {name}!",
        "footer_text": "Wishing you warmth, growth, and beautiful moments",
    },
    {
        "theme_name": "Ocean Breeze",
        "header_emoji_text": "🌊 Happy Birthday, {name}!",
        "footer_text": "Refreshing wishes from the Recruitment Team",
    },
    {
        "theme_name": "Autumn Warmth",
        "header_emoji_text": "🍂 Warm Birthday Wishes, {name}",
        "footer_text": "Cozy wishes from the Recruitment Team",
    },
    {
        "theme_name": "Midnight Fireworks",
        "header_emoji_text": "🎆 Happy Birthday, {name}!",
        "footer_text": "A little spark of trivia for your day",
    },
    {
        "theme_name": "Garden Party",
        "header_emoji_text": "🌷 Happy Birthday, {name}!",
        "footer_text": "May your day be as delightful as a garden in full bloom",
    },
]


HEADER_VARIANTS = [
    "Hi {name}, the whole Recruitment Team is throwing confetti your way today! 🎊 Hope your journey with us brings many more celebrations. Have a fantastic birthday!",
    "Dear {name}, on your special day, the Recruitment Team wishes you a year as golden as this cake. 🎂 Thank you for being part of our candidate journey — enjoy every moment!",
    "Hey {name}! 🎈 The Recruitment Team is sending balloons full of good wishes your way. May this year bring you exciting opportunities and happiness. Happy Birthday!",
    "Dear {name}, under a sky full of stars, the Recruitment Team wishes you a birthday as bright as your potential. ⭐ Here's to a wonderful year ahead!",
    "Hola {name}! 🌴 The Recruitment Team is celebrating your day, fiesta-style. Wishing you sunshine, success, and a very happy birthday!",
    "Hi {name}, the Recruitment Team wishes you a birthday bursting with color and joy. 🌈 May the year ahead be as vibrant as you are. Happy Birthday!",
    "Dear {name}, on behalf of the Recruitment Team, warm wishes on your birthday. We're glad to have you connected with us — here's to a year of growth and success.",
    "Hi {name}, like flowers in full bloom, may this year bring you fresh opportunities and happiness. 🌸 Warm birthday wishes from the Recruitment Team.",
    "Dear {name}, the Recruitment Team wishes you a birthday that sparkles as bright as the cosmos. ✨ May your journey ahead be out of this world. Happy Birthday!",
    "Hey {name}! 🎉 Pop the confetti — it's your day! The Recruitment Team wishes you a joyful birthday and an even better year ahead.",
    "Dear {name},\n\nAs the Recruitment Team, we're delighted to wish you a very happy birthday today. 🌅 May this new year of your life bring warmth, growth, and beautiful moments.\n\nHere's a little something fun for your special day:",
    "Hi {name},\n\nWishing you a birthday as refreshing as an ocean breeze. 🌊 The Recruitment Team hopes your year ahead sails smoothly, filled with success and good health.\n\nAnd here's a fun fact to go with your celebration:",
    "Dear {name},\n\nOn this cozy autumn day, the Recruitment Team sends you warm birthday wishes. 🍂 May the season's colors reflect the richness of the year that awaits you.\n\nBefore the celebrations continue, here's something interesting:",
    "Hi {name},\n\nThe Recruitment Team is lighting up the sky for your birthday today. 🎆 May this year bring bright ideas, big wins, and even bigger smiles.\n\nA little spark of trivia for you:",
    "Dear {name},\n\nHappy Birthday from all of us at the Recruitment Team! 🌷 May your day be as delightful as a garden in full bloom, and your year ahead just as flourishing.\n\nHere's something fun to add to the celebration:",
]


def get_theme(index: Optional[int] = None) -> Dict:
    """Return a theme dict. If index is None, pick randomly."""
    if index is None:
        return random.choice(THEMES)
    if 0 <= index < len(THEMES):
        return THEMES[index]
    raise IndexError("Theme index out of range")


def get_header_variant(index: Optional[int] = None, name: str = "") -> str:
    """Return formatted header paragraph (long body text) by index or randomly.

    If index is provided, it selects that header; otherwise picks randomly.
    """
    if index is None:
        txt = random.choice(HEADER_VARIANTS)
    else:
        txt = HEADER_VARIANTS[index % len(HEADER_VARIANTS)]
    return txt.format(name=name)


__all__ = ["THEMES", "HEADER_VARIANTS", "get_theme", "get_header_variant"]